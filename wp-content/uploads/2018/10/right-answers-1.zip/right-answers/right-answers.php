<?php
   /*
   Plugin Name: Right Answers
   Plugin URI: https://sonicwall.com
   Description: A plugin to retreive answers from Upland Right Answers
   Version: 1.0
   Author: Russell Kasselman
   Author URI: https://irondogmedia.com
   License: GPL2
   
   Things to do on this page
   1. 
 
   */

if(!class_exists('RightAnswers')) {
    class RightAnswers {
        /**
         * Construct the plugin object
         */
        public function __construct() {
			// Initialize shortcodes
			add_shortcode( 'ra-search', array( &$this, 'solution_search_page' ) ); 
			
			//Include any files needed for the operation of the plugins
			require_once(plugin_dir_path( __FILE__ ) . '/right-answers-admin.php');
			
			add_action('wp_enqueue_scripts', array( &$this, 'right_answers_public_scripts') );
			add_action('admin_enqueue_scripts', array( &$this, 'right_answers_admin_scripts') );
	
        } // END public function __construct

        /**
         * Activate the plugin
         */
        public static function activate() {
	        // Initialize table to store database information
			global $wpdb;
				//$table = $wpdb->prefix . '[insert name of table]'; 
				// $sql = 'CREATE TABLE IF NOT EXISTS ' . $table . ' (
				//id int(11) NOT NULL  PRIMARY KEY  AUTO_INCREMENT,
				//name_of_field VARCHAR(255) NOT NULL,
				// more_fields...
				//)';
    		
    		//the file below is required to make sure all proper wordpress core files are included
    		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    		//command to execute sql query from above
    		// dbDelta( $sql );
          
        } // END public static function activate
 
        public static function deactivate() {
            // If you need to do anything on the deactivation, you do it here
        } 

        public static function uninstall() {
        	// This is where you should clean up any database tables or other stuff you may have inserted into the site
        }
		
		public function  right_answers_public_scripts() {
			// wp_enqueue_script('jquery'); 
			
			// wp_register_style('plugin-name-style-nickname', plugins_url('/css/plugin-name-styles.css', __FILE__));
			// wp_enqueue_style('plugin-name-style-nickname');

			// wp_register_style('plugin-admin-style-nickname', plugins_url('/css/plugin-admin-style.css', __FILE__), '', '4.3.1');
			// wp_enqueue_style('plugin-admin-style-nickname');

			// wp_register_script('plugin-custom-js-nickname', plugins_url('/js/plugin-custom-js-script.js', __FILE__));
			// wp_enqueue_script('plugin-custom-js-nickname');
		}
		
		public function right_answers_admin_scripts() {
		//     wp_register_style('plugin-name-admin-mods-nickname', plugins_url('/css/plugin-name-admin-mods.css', __FILE__));
		//     wp_enqueue_style('plugin-name-admin-mods-nickname'); 
		 }
        
        public function solution_search_page( $atts, $content = null ) {

			// Enable output buffering
			ob_start();

			// Render template
			
			include plugin_dir_path( __FILE__ ) . 'templates/ra-search.php';

			// Return buffer
			$contents = ob_get_contents();
			ob_end_clean();
			return $contents;
		}
        
        
    } // END RightAnswers
} // END if class exists ('RightAnswers')

if(class_exists('RightAnswers')) {
    // Installation and uninstallation hooks
    register_activation_hook(__FILE__, array('RightAnswers', 'activate'));
    register_deactivation_hook(__FILE__, array('RightAnswers', 'deactivate'));
    register_uninstall_hook(__FILE__, array('RightAnswers', 'uninstall')); 

    // instantiate the plugin class
    $wp_plugin_template = new RightAnswers();
}



?>