<?php

	if ( isset( $_POST['search_submit'] ) && $_POST['search_submit'] == 'Search' ){

		$search_term = strip_tags($_POST['search_term']);
		$search_term = urldecode($search_term);
		$search_term = htmlentities($search_term);

		$ra = new RightAnswers();
		$search = $ra->get_a_solution($search_term);

		var_dump($search);
	}

?>

<p>Search for your answers</p>

<form action="#" method="post">
	<p>
		<label for="search_term">Enter Search Term</label>
		<input type="text" name="search_term" />
	</p>
	<p>
		<input type="submit" name="search_submit" value="Search">
	</p>
</form>
