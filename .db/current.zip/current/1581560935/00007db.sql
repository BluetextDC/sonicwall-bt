version https://git-lfs.github.com/spec/v1
oid sha256:69c56f14e56d3bd02ba0ef31ac6c35044e42469d5cf95e550c12d137d08e996c
size 49707867
